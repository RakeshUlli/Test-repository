package Assignment1;



public class Task8 {

	public static void main(String[] args) {
		//Example- 78,12,89,55,35
		
		int [] marks = {78,12,89,55,35};
		for(int i=0;i<=4;i++) {
			if(marks[i]>=80) {
				System.out.println("Scored marks more than 80 is "+marks[i]);
				
			}
		}
		
		

	}
}
