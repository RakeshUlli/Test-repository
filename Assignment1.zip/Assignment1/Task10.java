package Assignment1;

public class Task10 {

	public static void main(String[] args) {
		//Input � [�Java�,�JavaScript�,�Selenium�,�Python�,�Mukesh�]
		String[] str= {"Java","JavaScript","Selenium","Python","Mukesh"};
for(int i=0;i<=4;i++)	{
	if(str[i]!="Selenium") {
		
		System.out.println(str[i]);
	}
	else {
		
		break;
	}
}
		
		

	}

}
